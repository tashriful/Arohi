 <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">
          
          <li class="nav-item"><a class="nav-link" href="{{ route('b2b.index') }}"><span class="menu-title">Dashboard</span></a></li>
          <li class="nav-item"><a class="nav-link" href="{{ route('b2b.hotelAdd') }}"><span class="menu-title">Hotel Add</span></a></li>
          <li class="nav-item"><a class="nav-link" href="{{ route('b2b.hotelRoom') }}"><span class="menu-title">Hotel Rooms Add</span></a></li>
          <li class="nav-item"><a class="nav-link" href="{{ route('b2b.hotelList') }}"><span class="menu-title">Hotel & Rooms List</span></a></li>
          
          <li class="nav-item"><a class="nav-link" href="{{ route('admin.order') }}"><span class="menu-title">Order List</span></a></li>
         
          
          
          
         
        </ul>
      </nav>