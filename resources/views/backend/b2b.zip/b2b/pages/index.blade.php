@extends('backend.b2b.layouts.master')
      @section('content')
      
      <div class="main-panel">
          <div class="content-wrapper">
              <div class="card">
                  <div class="card-header">
                  </div>
                  <div class="card-body">
                      <h1>Welcome to B2B panel</h1>
                     
                     
                  </div>
              </div>


          </div>
      </div>


      @endsection